package com.example.demo.response;

import java.time.LocalDateTime;

public class TransactionHistoryResponse {
    private String invoiceNumber;
    private String transactionType;
    private String description;
    private double totalAmount;
    private LocalDateTime createdOn;

    public TransactionHistoryResponse(String invoiceNumber, String transactionType, String description, double totalAmount, LocalDateTime createdOn) {
        this.invoiceNumber = invoiceNumber;
        this.transactionType = transactionType;
        this.description = description;
        this.totalAmount = totalAmount;
        this.createdOn = createdOn;
    }
}
